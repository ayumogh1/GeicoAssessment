﻿using Microsoft.EntityFrameworkCore;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using TaskManager_GeicoAssessment_RamyaRao.Models;
using static TaskManager_GeicoAssessment_RamyaRao.Models.Tasks;

namespace TaskManager_GeicoAssessment_RamyaRao.Data
{
    [ExcludeFromCodeCoverage]
    public class TaskManagerDataContext : DbContext
    {
        public TaskManagerDataContext()
        {

        }
        public TaskManagerDataContext(DbContextOptions<TaskManagerDataContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=chs6ramyarao01\\SQLEXPRESS;Database=TaskManager;Trusted_Connection=True;");
        }
       

        public DbSet<Tasks> Tasks { get; set; }
    }
}
