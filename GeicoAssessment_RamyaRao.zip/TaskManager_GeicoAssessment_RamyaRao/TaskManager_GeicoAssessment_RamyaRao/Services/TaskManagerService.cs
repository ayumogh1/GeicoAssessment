﻿using Microsoft.AspNetCore.Mvc;
using TaskManager_GeicoAssessment_RamyaRao.Interfaces;
using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.Services
{
    public class TaskManagerService : ITaskManagerService
    {
        private readonly ITaskManagerRepository _repo;
        public TaskManagerService(ITaskManagerRepository repo)
        {
            _repo = repo;
        }

        public async Task<Tasks> ProcessCreateNewTask(Tasks tasks)            
        {
            if(tasks.Priority == "High")
            {
                var highprioritytaskCount =  CountExistingHighPriorityTasks(tasks.DueDate);
                if (highprioritytaskCount.Result >= 100)
                {
                    throw new ArgumentException("Cannot process the task. The system already has 100 High Priority tasks");
                }
            }            

            await _repo.CreateNewTask(tasks);
            return tasks;
        }

        public async Task<List<Tasks>> ProcessGetAllTasks()
        {
            return await _repo.GetAllTasksAsync();
        }

        public async Task<string> ProcessUpdateTaskById(int id, Tasks tasks) 
        {
            if(id != tasks.Id)
            {
                throw new ArgumentException("The id in Request body does not match the id in parameter.");
            }
            if (tasks.Priority == "High")
            {
                var highprioritytaskCount = CountExistingHighPriorityTasks(tasks.DueDate);
                if (highprioritytaskCount.Result > 100)
                {
                    throw new ArgumentException("Cannot process the task. The system already has 100 High Priority tasks");
                }
            }
            return await _repo.UpdateTaskById(id, tasks);
        }

       

        public async Task<Tasks> ProcessGetTasksById(int taskId)
        {
            return await _repo.GetTasksById(taskId);
        }
              


        private async Task<int> CountExistingHighPriorityTasks(DateTime dueDate)
        {
            var AllTasks = await _repo.GetAllTasksAsync();
            var highPriority = AllTasks.ToList().Where(t => (t.Priority == "High" && t.Status != "Finished" && t.DueDate.Date == dueDate.Date));
            if(highPriority == null)
            {
                return 0;
            }
            else {
                return highPriority.Count(); 
            }           

        }
    }
}
