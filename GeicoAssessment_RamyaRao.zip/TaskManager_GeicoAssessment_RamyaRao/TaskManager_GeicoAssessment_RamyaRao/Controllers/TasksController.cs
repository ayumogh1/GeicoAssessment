﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager_GeicoAssessment_RamyaRao.Data;
using TaskManager_GeicoAssessment_RamyaRao.Interfaces;
using TaskManager_GeicoAssessment_RamyaRao.Models;
using TaskManager_GeicoAssessment_RamyaRao.Services;

namespace TaskManager_GeicoAssessment_RamyaRao.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly ITaskManagerService _service;

        public TasksController(ITaskManagerService service)
        {
            _service = service ?? throw new ArgumentNullException(nameof(TaskManagerService));
        }

        // GET: api/Tasks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tasks>>> GetTasks()
        {         
            var response = await _service.ProcessGetAllTasks().ConfigureAwait(false);
            return response != null ? Ok(response) : NotFound();
        }

        // GET: api/Tasks/5
       [HttpGet("{id}")]
       public async Task<ActionResult<Tasks>> GetTasks(int id)
       {
         var response = await _service.ProcessGetTasksById(id);
         return response != null ? Ok(response) : NotFound();
        }
       //

       [HttpPut("{id}")]
       public async Task<ActionResult<string>> PutTasks(int id, Tasks tasks)
       {
            var response = await _service.ProcessUpdateTaskById(id, tasks);
            return response != string.Empty ? Ok(response) : NotFound();
        }
       //

       [HttpPost]
       public async Task<ActionResult> PostTasks(Tasks tasks)
       {
            var response = await _service.ProcessCreateNewTask(tasks);
            return response != null ? Ok(response) : NotFound();
        }
       
    }
}
