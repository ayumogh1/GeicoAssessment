﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;
using TaskManager_GeicoAssessment_RamyaRao.Data;
using TaskManager_GeicoAssessment_RamyaRao.Interfaces;
using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.DataAccessLayer
{
    [ExcludeFromCodeCoverage]
    public class TaskManagerRepository : ITaskManagerRepository
    {
        private readonly TaskManagerDataContext _context;

        public TaskManagerRepository(TaskManagerDataContext context)
        {
            _context = context;
        }

        public async Task<Tasks> CreateNewTask(Tasks tasks)
        {
            _context.Tasks.Add(tasks);
             await _context.SaveChangesAsync();        
            return tasks;
            
        }

        public async Task<List<Tasks>> GetAllTasksAsync()
        {
            return  _context.Tasks.ToList();
        }

        public async Task<Tasks> GetTasksById(int id)
        {
            var tasks = await _context.Tasks.FindAsync(id);
            if(tasks == null)
            {
                return null;
            }
            return tasks;
        }

        public async Task<string> UpdateTaskById(int id, Tasks tasks)
        {
            if(id != tasks.Id)
            {
                throw new Exception("Values to update dont match the record");
            }
            try
            {
                await _context.SaveChangesAsync();
            }
            catch(DbUpdateConcurrencyException)
            {
                if (!TasksExists(id))
               {
                   return "Record to update not found";
               }
               else
               {
                   throw;
               }
            }
            return "Record updated successfully";
        }


        private bool TasksExists(int id)
        {
            return (_context.Tasks?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
