﻿using FluentValidation;
using System.Diagnostics.CodeAnalysis;
using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.Validators
{
    public class TasksValidator : AbstractValidator<Tasks>
    {
        [ExcludeFromCodeCoverage]
        public TasksValidator()
        {
            List<string> priorities = new List<string>() { "High", "Medium", "Low" };

            List<string> Status = new List<string>() { "New", "In Progress", "Finished" };

            RuleFor(x => x.DueDate).NotEmpty().GreaterThan(DateTime.Now).WithMessage("DueDate cannot be in the Past");

            RuleFor(x => x.Priority).NotEmpty().Must(y => priorities.Contains(y))
                .WithMessage("Please only use: " + String.Join(",", priorities));

            RuleFor(x => x.Status).NotEmpty().Must(y => Status.Contains(y))
               .WithMessage("Please only use: " + String.Join(",", Status));
        }
    }
}
