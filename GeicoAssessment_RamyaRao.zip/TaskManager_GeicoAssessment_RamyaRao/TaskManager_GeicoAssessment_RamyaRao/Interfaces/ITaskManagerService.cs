﻿using Microsoft.AspNetCore.Mvc;
using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.Interfaces
{
    public interface ITaskManagerService
    {
        Task<List<Tasks>> ProcessGetAllTasks();

        Task<Tasks> ProcessGetTasksById(int taskId);


        Task<string> ProcessUpdateTaskById(int id, Tasks tasks);

        Task<Tasks> ProcessCreateNewTask(Tasks tasks);
    }
}
