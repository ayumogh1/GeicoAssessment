﻿using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.Interfaces
{
    public interface ITaskManagerRepository
    {
        Task<List<Tasks>> GetAllTasksAsync();


        Task<Tasks> GetTasksById(int id);

        Task<string> UpdateTaskById(int id, Tasks tasks);

        Task<Tasks> CreateNewTask(Tasks tasks);

    }
}
