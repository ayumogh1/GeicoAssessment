﻿using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace TaskManager_GeicoAssessment_RamyaRao.Models
{

    [ExcludeFromCodeCoverage]
    public class Tasks
    {
        public int Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; } = string.Empty;


        public DateTime DueDate { get; set; }

        public DateTime StartDate { get; set; }

        public String Priority { get; set; }

        public string Status { get; set; }
    }
}
