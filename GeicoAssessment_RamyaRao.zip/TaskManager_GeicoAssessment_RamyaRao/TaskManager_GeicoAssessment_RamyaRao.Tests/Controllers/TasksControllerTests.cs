﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using AutoFixture;
using FluentAssertions;
using TaskManager_GeicoAssessment_RamyaRao.Interfaces;
using TaskManager_GeicoAssessment_RamyaRao.Controllers;
using TaskManager_GeicoAssessment_RamyaRao.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace TaskManager_GeicoAssessment_RamyaRao.Tests.Controllers
{
   
    public class TasksControllerTests
    {
        private readonly IFixture _fixture;
        private readonly Mock<ITaskManagerService> _taskManagerServiceMock;
        private readonly TasksController _controller;

        public TasksControllerTests()
        {
            _fixture = new Fixture();
            _taskManagerServiceMock = _fixture.Freeze<Mock<ITaskManagerService>>();
            _controller = new TasksController(_taskManagerServiceMock.Object);

        }
        [Fact]
        public async Task GetTasks_ShouldreturnOKResponse_WhenSuccessfull()
        {
            //Arrange
            var TasksMock = _fixture.Create<List<Tasks>>();
            _taskManagerServiceMock.Setup(x => x.ProcessGetAllTasks()).ReturnsAsync(TasksMock);

            //Act
            var result = await _controller.GetTasks().ConfigureAwait(false);

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<IEnumerable<Tasks>>>();
            result.Result.Should().BeAssignableTo<OkObjectResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessGetAllTasks(), Times.Once);
            result.Result.As<OkObjectResult>().Value
                .Should()
                .NotBeNull();

        }
        [Fact]
        public async Task GetTasks_ShouldreturnNotFoundResponse_WhenNotSuccessfull()
        {
            //Arrange
            List<Tasks> response = null;
            _taskManagerServiceMock.Setup(x => x.ProcessGetAllTasks()).ReturnsAsync(response);

            //Act
            var result = await _controller.GetTasks().ConfigureAwait(false);

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<IEnumerable<Tasks>>>();
            result.Result.Should().BeAssignableTo<NotFoundResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessGetAllTasks(), Times.Once);
        }

        [Fact]
        public async Task GetTasks_WhenCalledWithId_ShouldreturnOKResponse_WhenSuccessfull()
        {
            //Arrange
            var TaskMock = _fixture.Create<Tasks>();
            _taskManagerServiceMock.Setup(x => x.ProcessGetTasksById(It.IsAny<int>())).ReturnsAsync(TaskMock);

            //Act
            var result = await _controller.GetTasks(It.IsAny<int>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<Tasks>>();
            result.Result.Should().BeAssignableTo<OkObjectResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessGetTasksById(It.IsAny<int>()), Times.Once);
            result.Result.As<OkObjectResult>().Value
                .Should()
                .NotBeNull();
           
        }

        [Fact]
        public async Task GetTasks_WhenCalledWithId_ShouldreturnNotFoundResponse_WhenNotSuccessfull()
        {
            //Arrange
            Tasks response = null;
            _taskManagerServiceMock.Setup(x => x.ProcessGetTasksById(It.IsAny<int>())).ReturnsAsync(response);

            //Act
            var result = await _controller.GetTasks(It.IsAny<int>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<Tasks>>();
            result.Result.Should().BeAssignableTo<NotFoundResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessGetTasksById(It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task PutTasks_WhenCalledWithId_ShouldreturnOKResponse_WhenSuccessfull()
        {
            //Arrange
            _taskManagerServiceMock.Setup(x => x.ProcessUpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>())).ReturnsAsync("Mock Value");

            //Act
            var result = await _controller.PutTasks(It.IsAny<int>(), It.IsAny<Tasks>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<string>>();
            result.Result.Should().BeAssignableTo<OkObjectResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessUpdateTaskById(It.IsAny<int>(),  It.IsAny<Tasks>()), Times.Once);
            result.Result.As<OkObjectResult>().Value
                .Should()
                .NotBeNull();

        }

        [Fact]
        public async Task PutTasks_WhenCalledWithId_ShouldreturnNotFoundResponse_WhenNotSuccessfull()
        {
            //Arrange
            _taskManagerServiceMock.Setup(x => x.ProcessUpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>())).ReturnsAsync(string.Empty);

            //Act
            var result = await _controller.PutTasks(It.IsAny<int>(), It.IsAny<Tasks>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<ActionResult<string>>();
            result.Result.Should().BeAssignableTo<NotFoundResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessUpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>()), Times.Once);
        }

        [Fact]
        public async Task PostTasks_WhenCalledWithId_ShouldreturnOKResponse_WhenSuccessfull()
        {
            //Arrange
            var TaskMock = _fixture.Create<Tasks>();
            _taskManagerServiceMock.Setup(x => x.ProcessCreateNewTask(It.IsAny<Tasks>())).ReturnsAsync(TaskMock);

            //Act
            var result = await _controller.PostTasks(It.IsAny<Tasks>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<OkObjectResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessCreateNewTask(It.IsAny<Tasks>()), Times.Once);
      

        }

        [Fact]
        public async Task PostTasks_WhenCalledWithId_ShouldreturnNotFoundResponse_WhenNotSuccessfull()
        {
            //Arrange
            Tasks TaskMock = null;
           _taskManagerServiceMock.Setup(x => x.ProcessCreateNewTask(It.IsAny<Tasks>())).ReturnsAsync(TaskMock);

            //Act
            var result = await _controller.PostTasks(It.IsAny<Tasks>());

            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<NotFoundResult>();
            _taskManagerServiceMock.Verify(x => x.ProcessCreateNewTask(It.IsAny<Tasks>()), Times.Once);
        }


    }
}
