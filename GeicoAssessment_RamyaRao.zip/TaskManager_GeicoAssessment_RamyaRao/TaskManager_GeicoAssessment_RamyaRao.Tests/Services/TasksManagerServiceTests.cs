﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using FluentAssertions;
using AutoFixture;
using TaskManager_GeicoAssessment_RamyaRao.Interfaces;
using TaskManager_GeicoAssessment_RamyaRao.Services;
using TaskManager_GeicoAssessment_RamyaRao.Models;

namespace TaskManager_GeicoAssessment_RamyaRao.Tests.Services
{
    public class TasksManagerServiceTests
    {
        private readonly IFixture _fixture;
        private readonly Mock<ITaskManagerRepository> _taskManagerRepository;
        private readonly TaskManagerService _sut;
        public TasksManagerServiceTests()
        {
            _fixture = new Fixture { RepeatCount = 101 };
            _taskManagerRepository = _fixture.Freeze<Mock<ITaskManagerRepository>>();
            _sut = new TaskManagerService(_taskManagerRepository.Object);
        }

        [Fact]
        public async Task ProcessGetAllTasks_ShouldReturnData_WhenDataFound()
        {
            //Arrange
            var TaskListMock = _fixture.Create<List<Tasks>>();
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessGetAllTasks();


            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<List<Tasks>>();
            _taskManagerRepository.Verify(x => x.GetAllTasksAsync(),Times.Once());
        }

        [Fact]
        public async Task ProcessGetAllTasks_ShouldReturnNull_WhenDataNotFound()
        {
            //Arrange
            List<Tasks> TaskListMock = null;
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessGetAllTasks();


            //Assert
            result.Should().BeNull();
            _taskManagerRepository.Verify(x => x.GetAllTasksAsync(), Times.Once());
        }

        [Fact]
        public async Task ProcessGetTasksById_ShouldReturnData_WhenDataFound()
        {
            //Arrange
            var TaskListMock = _fixture.Create<Tasks>();
            _taskManagerRepository.Setup(x => x.GetTasksById(It.IsAny<int>())).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessGetTasksById(It.IsAny<int>());


            //Assert
            result.Should().NotBeNull();
            result.Should().BeAssignableTo<Tasks>();
            _taskManagerRepository.Verify(x => x.GetTasksById(It.IsAny<int>()), Times.Once());
        }

        [Fact]
        public async Task ProcessGetTasksByIds_ShouldReturnNull_WhenDataNotFound()
        {
            //Arrange
            Tasks TaskListMock = null;
            _taskManagerRepository.Setup(x => x.GetTasksById(It.IsAny<int>())).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessGetTasksById(It.IsAny<int>());


            //Assert
            result.Should().BeNull();
            _taskManagerRepository.Verify(x => x.GetTasksById(It.IsAny<int>()), Times.Once());
        }

        [Fact]
        public async Task ProcessCreateNewTask_ShouldReturn_WhenDataCreated()
        {
            //Arrange
            var TaskMock = _fixture.Create<Tasks>();
            TaskMock.Priority = "High";
            _taskManagerRepository.Setup(x => x.CreateNewTask(It.IsAny<Tasks>())).ReturnsAsync(TaskMock);
            var TaskListMock = _fixture.Create<List<Tasks>>();

            foreach (var task in TaskListMock)
            {
                task.Priority = "Low";
                task.Status = "New";
            }
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessCreateNewTask(TaskMock);


            //Assert
            result.Should().NotBeNull();
            _taskManagerRepository.Verify(x => x.CreateNewTask(It.IsAny<Tasks>()), Times.Once());
        }

        [Fact]
        public void ProcessCreateNewTask_ShouldThrow_WhenException()
        {
            //Arrange
            var TaskMock = _fixture.Create<Tasks>();
            TaskMock.Priority = "High";
            _taskManagerRepository.Setup(x => x.CreateNewTask(It.IsAny<Tasks>()));
            var TaskListMock = _fixture.Create<List<Tasks>>();

            foreach(var task in TaskListMock)
            {
                task.Priority = "High";
                task.Status = "New";
                task.DueDate = TaskMock.DueDate;
            }
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = () => _sut.ProcessCreateNewTask(TaskMock).Result;


            //Assert
            result.Should().Throw<ArgumentException>();
        }

        [Fact]
        public async Task ProcessUpdateTaskById_ShouldReturn_WhenDataCreated()
        {
            //Arrange
            var TaskListMock = _fixture.Create<List<Tasks>>();

            foreach (var task in TaskListMock)
            {
                task.Priority = "Low";
                task.Status = "New";
            }
            var TaskMock = TaskListMock.FirstOrDefault();
            var mockid = TaskMock.Id;
            TaskMock.Priority = "High";
            _taskManagerRepository.Setup(x => x.UpdateTaskById(It.IsAny<int>(),It.IsAny<Tasks>())).ReturnsAsync("Mock response");
           
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = await _sut.ProcessUpdateTaskById(mockid,TaskMock);


            //Assert
            result.Should().NotBeNull();
            _taskManagerRepository.Verify(x => x.UpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>()), Times.Once());
        }

        [Fact]
        public void ProcessUpdateTaskById_ShouldThrow_WhenException_WhenIdDontMatch()
        {
            //Arrange
            var TaskMock = _fixture.Create<Tasks>();
            var mockid = TaskMock.Id + 1;
            TaskMock.Priority = "High";
            _taskManagerRepository.Setup(x => x.UpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>()));
            var TaskListMock = _fixture.Create<List<Tasks>>();

            foreach (var task in TaskListMock)
            {
                task.Priority = "High";
                task.Status = "New";
            }
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = () => _sut.ProcessUpdateTaskById(mockid,TaskMock).Result;


            //Assert
            result.Should().Throw<ArgumentException>();
        }

        [Fact]
        public void ProcessUpdateTaskById_ShouldThrow_WhenException_WhenMoreThan100_HighPriorityTasks()
        {
            //Arrange
            var TaskListMock = _fixture.Create<List<Tasks>>();
            var TaskMock = TaskListMock.FirstOrDefault();
            foreach (var task in TaskListMock)
            {
                task.Priority = "High";
                task.Status = "New";
                task.DueDate = TaskMock.DueDate;
            }
           
            var mockid = TaskMock.Id ;
            TaskMock.Priority = "High";
            _taskManagerRepository.Setup(x => x.UpdateTaskById(It.IsAny<int>(), It.IsAny<Tasks>()));
            
            _taskManagerRepository.Setup(x => x.GetAllTasksAsync()).ReturnsAsync(TaskListMock);

            //Act
            var result = () => _sut.ProcessUpdateTaskById(mockid, TaskMock).Result;


            //Assert
            result.Should().Throw<ArgumentException>();
        }
    }
}
